var $j = jQuery.noConflict();

$j(document).ready(function() {
    "use strict";
    StickyHeader();
});

function StickyHeader() {
    var header = $j('.elementor-element.mas-sticky-yes'),
        container = $j('.mas-sticky-yes .elementor-container, .elementor-element.mas-sticky-yes.e-con'),
        header_elementor = $j('.elementor-edit-mode .mas-sticky-yes'),
        header_logo = $j('.mas-sticky-yes .elementor-widget-theme-site-logo img:not(.elementor-widget-n-menu img), .mas-sticky-yes .elementor-widget-image img:not(.elementor-widget-n-menu img)'),
        data_settings = header.data('settings');

    if (typeof data_settings !== 'undefined') {
        var responsive_settings = data_settings["mas_transparent_on"];
        var width = $j(window).width(),
            header_height = header.height(),
            logo_width = header_logo.width(),
            logo_height = header_logo.height();
    }

    if (typeof width !== 'undefined' && width) {
        var enabled;
        if (width >= 1025) {
            enabled = "desktop";
        } else if (width > 767 && width < 1025) {
            enabled = "tablet";
        } else if (width <= 767) {
            enabled = "mobile";
        }
    }

    if ($j.inArray(enabled, responsive_settings) != '-1') {
        var scroll_distance = data_settings["mas_scroll_distance"];
        var transparent_header = data_settings["mas_transparent_header_show"];
        var background = data_settings["mas_background"];
        var bottom_border_color = data_settings["mas_custom_bottom_border_color"],
            bottom_border_view = data_settings["mas_bottom_border"],
            bottom_border_width = data_settings["mas_custom_bottom_border_width"];

        var shrink_header = data_settings["mas_shrink_header"],
            data_height = data_settings["mas_custom_height_header"],
            data_height_tablet = data_settings["mas_custom_height_header_tablet"],
            data_height_mobile = data_settings["mas_custom_height_header_mobile"];

        var shrink_logo = data_settings["mas_shrink_header_logo"],
            data_logo_height = data_settings["mas_custom_height_header_logo"],
            data_logo_height_tablet = data_settings["mas_custom_height_header_logo_tablet"],
            data_logo_height_mobile = data_settings["mas_custom_height_header_logo_mobile"];

        var change_logo_color = data_settings["mas_change_logo_color"];
        var blur_bg = data_settings["mas_blur_bg"];
        var scroll_distance_hide_header = data_settings["mas_scroll_distance_hide_header"];

        if (transparent_header === "yes") {
            header.addClass('mas-transparent-yes');
        }

        // Determine header height shrink based on responsive view
        var shrink_height;
        if (typeof data_height !== "undefined" && data_height) {
            if (width >= 1025) {
                shrink_height = data_height["size"];
            } else if (width > 767 && width < 1025) {
                shrink_height = data_height_tablet["size"] || data_height["size"];
            } else if (width <= 767) {
                shrink_height = data_height_mobile["size"] || data_height["size"];
            }
        }

        // Determine logo height shrink based on responsive view
        var shrink_logo_height;
        if (typeof data_logo_height !== "undefined" && data_logo_height) {
            if (width >= 1025) {
                shrink_logo_height = data_logo_height["size"];
            } else if (width > 767 && width < 1025) {
                shrink_logo_height = data_logo_height_tablet["size"] || data_logo_height["size"];
            } else if (width <= 767) {
                shrink_logo_height = data_logo_height_mobile["size"] || data_logo_height["size"];
            }

            var percent = parseInt(shrink_logo_height) / parseInt(header_height);
            var width_l = logo_width * percent;
            var height_l = logo_height * percent;
        }

        if (typeof bottom_border_width !== 'undefined' && bottom_border_width) {
            var bottom_border = bottom_border_width["size"] + "px solid " + bottom_border_color;
        }

        // Scroll behavior for hiding/showing header
        $j(window).on("scroll", function() {
            var scroll = $j(window).scrollTop();

            if (scroll >= scroll_distance["size"]) {
                header.addClass("mas-sticky-header").css({
                    "background-color": background,
                    "border-bottom": bottom_border
                }).removeClass('mas-header-transparent-yes');

                if (shrink_header === "yes") {
                    header.css({"padding": "0", "margin": "0"});
                    container.css({
                        "min-height": shrink_height,
                        "transition": "all 0.4s ease-in-out"
                    });
                }

                if (change_logo_color === "yes") {
                    header_logo.addClass("change-logo-color");
                }

                if (shrink_logo === "yes") {
                    header_logo.css({
                        width: width_l,
                        transition: "all 0.4s ease-in-out"
                    });
                }

            } else {
                header.removeClass("mas-sticky-header").css({
                    "background-color": "",
                    "border-bottom": ""
                }).addClass('mas-header-transparent-yes');

                if (shrink_header === "yes") {
                    container.css("min-height", "");
                }

                if (shrink_logo === "yes") {
                    header_logo.css({ height: "", width: "" });
                }

                if (change_logo_color === "yes") {
                    header_logo.removeClass("change-logo-color");
                }
            }
        });
    }
}
