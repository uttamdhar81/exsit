var $j = jQuery.noConflict();

$j(document).ready(function() {
    "use strict";
    StickyHeader();
});

function StickyHeader() {
    var header = $j('.elementor-element.mas-sticky-yes'),
        container = $j('.mas-sticky-yes .elementor-container, .elementor-element.mas-sticky-yes.e-con'),
        data_settings = header.data('settings');

    if (typeof data_settings !== 'undefined') {
        var responsive_settings = data_settings["mas_transparent_on"] || [];
        
        // Check viewport width and determine device type
        var width = $j(window).width();
        var enabled;

        if (width >= 1025) {
            enabled = "desktop";
        } else if (width > 767 && width < 1025) {
            enabled = "tablet";
        } else if (width <= 767) {
            enabled = "mobile";
        }

        // Only apply sticky behavior if the current device is in the responsive settings array
        if (responsive_settings.includes(enabled)) {
            var scroll_distance = data_settings["mas_scroll_distance"];
            var background = data_settings["mas_background"];
            var shrink_header = data_settings["mas_shrink_header"];
            var data_height = data_settings["mas_custom_height_header"];

            // Scroll behavior for sticky header
            $j(window).on("scroll", function() {
                var scroll = $j(window).scrollTop();

                if (scroll >= scroll_distance["size"]) {
                    header.addClass("mas-sticky-header").css({
                        "background-color": background,
                    });

                    if (shrink_header === "yes") {
                        header.css({"padding": "0", "margin": "0"});
                        container.css({
                            "min-height": data_height ? data_height["size"] : "",
                            "transition": "all 0.4s ease-in-out"
                        });
                    }

                } else {
                    header.removeClass("mas-sticky-header").css({
                        "background-color": "",
                    });

                    if (shrink_header === "yes") {
                        container.css("min-height", "");
                    }
                }
            });
        } else {
            // Remove any existing sticky classes if they were set
            header.removeClass("mas-sticky-header");
        }
    }
}
