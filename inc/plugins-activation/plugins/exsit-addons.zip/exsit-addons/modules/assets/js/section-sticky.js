(function ($) {

    "use strict";

    var HTMegaAdvanceStickyHandler = function ($scope) {
        
        if (!$scope.hasClass("mas-section-sticky-yes")) {
            return;
        }
        
        var stickyWrapperArea = $($scope[0]),
            editorStickyWrapper = $scope.find('.mas-section-sticky-editor'),
            editMode = elementorFrontend.isEditMode(),
            stickyData = '',
            defaultPosition = 'static';
        
        if (editMode) {
            stickyData = editorStickyWrapper.data('sticky_settings');
            defaultPosition = 'relative';
        } else {
            stickyData = JSON.parse(stickyWrapperArea[0].dataset['sticky_settings']);
        }

        if (undefined === stickyData) {
            return;
        }

        let sPosition = stickyData.position || 'top',
            sOffset = parseInt(stickyData.offset) || 0,
            sZindex = stickyData.z_index || '99',
            stickyOnScrollUp = stickyData.sticky_on_scroll_up || 'no',
            hideOnTablet = stickyData.hide_on_tablet || 'no',
            hideOnMobile = stickyData.hide_on_mobile || 'no',
            stickyAnimation = stickyData.sticky_animation === 'yes' ? 'yes' : 'no',
            clPosition = sPosition,
            stickyWrapHegiht = stickyWrapperArea.outerHeight(true),
            totalOffset = stickyWrapperArea.offset().top + stickyWrapHegiht,
            sectionWidth = stickyWrapperArea.outerWidth(),
            columnOffset = 0;

        if ('column' == sPosition) {
            sPosition = 'top';
            totalOffset = stickyWrapperArea.offset().top;
            let columnArea = stickyWrapperArea.parents('.elementor-widget-wrap').outerHeight();
            columnOffset = stickyWrapperArea.offset().top + parseInt(columnArea) - stickyWrapHegiht;

            if ('center' == $(stickyWrapperArea.parents('.elementor-widget-wrap')).css('align-items')) {
                columnOffset = columnOffset - (stickyWrapHegiht / 2);
            }
            if ('flex-end' == $(stickyWrapperArea.parents('.elementor-widget-wrap')).css('align-items')) {
                columnOffset = columnOffset - stickyWrapHegiht;
            }
        }

        let prevScrollPos = $(window).scrollTop();

        if (($( '#wpadminbar' ) && 'fixed' === $( '#wpadminbar' ).css('position')) && 'top' == sPosition) {
            var offset = $( '#wpadminbar' ).outerHeight(true);
            sOffset += offset;
        }

        var HTMegaStickyToggler = function () {
            var windowScroll = $(window).scrollTop() + sOffset;
            if ('column' != clPosition) {
                windowScroll = windowScroll + stickyWrapHegiht;
            }

            var isScrollingUp = windowScroll <= prevScrollPos;
            prevScrollPos = windowScroll;

            if (((('yes' == stickyOnScrollUp && isScrollingUp) && totalOffset <= windowScroll) || ('no' == stickyOnScrollUp && totalOffset <= windowScroll))) {
                stickyWrapperArea.addClass('mas-sticky-open');
                if (stickyWrapperArea.parents('.elementor-widget-wrap').length && 'column' != clPosition) {
                    stickyWrapperArea.css({'position': 'fixed', 'z-index': sZindex, 'max-width': sectionWidth + 'px', 'width': '100%'});
                } else {
                    stickyWrapperArea.css({'position': 'sticky', 'z-index': sZindex, 'max-width': sectionWidth + 'px', 'width': '100%'});
                }
                stickyWrapperArea.css(sPosition, sOffset + 'px');
            } else {
                stickyWrapperArea.removeClass('mas-sticky-open');
                stickyWrapperArea.css({'position': defaultPosition, 'z-index': ''});
                if ('yes' == stickyAnimation) {
                    stickyWrapperArea.css(sPosition, -stickyWrapHegiht + 'px');
                }
                if (editMode) {
                    stickyWrapperArea.css(sPosition, 0);
                }
            }

            // Column height sticky widget control
            if (columnOffset && columnOffset <= windowScroll) {
                stickyWrapperArea.removeClass('mas-sticky-open');
                stickyWrapperArea.css({'position': 'absolute', 'z-index': sZindex, 'bottom': '0', 'top': 'auto'});
            }
        };

        let activeDevices = 'yes';

        // Check for hide on tablet and mobile
        if ($(window).width() < 768 && 'yes' == hideOnMobile) {
            activeDevices = 'no'; 
          
        } else if ($(window).width() >= 768 && $(window).width() <= 1024 && 'yes' == hideOnTablet) {
            activeDevices = 'no'; 
            
        }

        if ('yes' == activeDevices) {
            HTMegaStickyToggler();
            $(window).scroll(HTMegaStickyToggler);
        }

        // Listen for window resize to update the device mode
        $(window).resize(function () {
            // Re-run the sticky handler to re-check the conditions when the window is resized
            HTMegaStickyToggler();
        });

    };

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/section", HTMegaAdvanceStickyHandler);
        elementorFrontend.hooks.addAction("frontend/element_ready/container", HTMegaAdvanceStickyHandler);
        elementorFrontend.hooks.addAction("frontend/element_ready/widget", HTMegaAdvanceStickyHandler);
    });

})(jQuery);
