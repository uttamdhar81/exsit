<?php 
namespace Mas\inc\SectionSticky;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Mas_Section_Sticky {

	private static $assets_load = null;

    private static $_instance = null;

    /**
     * Retrieves the singleton instance of the class.
     *
     * This method ensures that only one instance of the class is created
     * by checking if the instance is already initialized. If not, it creates
     * a new instance and returns it. It follows the Singleton design pattern
     * to restrict the instantiation of the class to a single object.
     *
     * @return self The singleton instance of the class.
     */

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }


    /**
     * Constructor for initializing the widget actions and hooks in Elementor.
     *
     * This method hooks various functions to Elementor's lifecycle events to:
     * - Register widget controls after the section's style settings.
     * - Handle the widget rendering process before it gets rendered on the frontend.
     * - Enqueue custom styles and scripts for the widget on the frontend.
     * - Ensure that assets (styles/scripts) are properly checked and enqueued before rendering.
     *
     */

    public function __construct() {
		
		add_action( 'elementor/element/column/section_advanced/after_section_end', array( $this, 'register_controls' ), 10 );
		add_action( 'elementor/element/section/section_advanced/after_section_end', array( $this, 'register_controls' ), 10 );
		add_action( 'elementor/element/container/section_layout/after_section_end', array( $this, 'register_controls' ), 10 );
		add_action( 'elementor/element/common/_section_style/after_section_end', array( $this, 'register_controls' ), 10 );


		add_action( 'elementor/frontend/section/before_render', array( $this, 'before_render' ), 10, 1 );
		add_action( 'elementor/frontend/container/before_render', array( $this, 'before_render' ), 10, 1 );
		add_action( 'elementor/frontend/widget/before_render', array( $this, 'before_render' ), 10, 1 );
		add_action( 'elementor/frontend/column/before_render', array( $this, 'before_render' ), 10, 1 );

        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);


		add_action( 'elementor/frontend/section/before_render', array( $this, 'check_assets_enqueue' ) );
		add_action( 'elementor/frontend/container/before_render', array( $this, 'check_assets_enqueue' ) );
		add_action( 'elementor/frontend/widget/before_render', array( $this, 'check_assets_enqueue' ));
		add_action( 'elementor/frontend/column/before_render', array( $this, 'check_assets_enqueue' ));

    }

	/**
	 * Enqueue styles.
	 *
	 * Registers required dependencies for the extension and enqueues them.
	 *
	 * @since 1.6.2
	 * @access public
	 */
	public static function enqueue_styles() {
		//CSS File
		wp_enqueue_style(  'mas-section-sticky',  MAS_PLUGDIRURI . 'modules/assets/css/section-sticky.css', array(), '1.0.0' );
	}

	/**
	 * Enqueue scripts.
	 *
	 * Enqueue required JS dependencies for the extension.
	 *
	 * @since 1.6.2
	 * @access public
	 */
	public static function enqueue_scripts() {
        // JS File
        wp_enqueue_script( 'mas-section-sticky', MAS_PLUGDIRURI . 'modules/assets/js/section-sticky.js', array('jquery'),'1.0.0' );

	}

	 //Register Sticky  controls.
	public function register_controls( $element ) {

		$element->start_controls_section(
			'section_mas_advanced_sticky',
			[
				'label' => __( 'Mas Section Sticky', 'mas-addons' ).mas_get_section_icon(),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'mas_advanced_sticky_switcher',
			[
				'label'        => __( 'Enable Sticky', 'mas-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'prefix_class' => 'mas-section-sticky-',
				'render_type'  => 'template',
			]
		);
		if ( strpos( current_filter(), 'common/' ) ) {
		
			$element->add_control(
				'mas-particles_notice',
				[
					'raw'             => __( 'The <b>Sticky settings</b> are not functional in Editor mode. Please preview the page to see the desired result.', 'mas-addons' ),
					'type'            => Controls_Manager::RAW_HTML,
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
					'condition'   => [
						'mas_advanced_sticky_switcher' => 'yes'
					],
				]
			);
		}
		$options = array(
			'top'  => __( 'Top', 'mas-addons' ),
			'column' => __( 'Column', 'mas-addons' ),
		);

		// if ( strpos( current_filter(), 'section/' ) ) {
		// 	unset( $options['column'] );
		// }
		$element->add_control (
			'mas_advanced_sticky_position',
			[
				'label' => __( 'Sticky Position', 'mas-addons' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => $options,
				'condition' => [
					'mas_advanced_sticky_switcher' => 'yes'
				]
			]
		);

		$element->add_control(
			'mas_advanced_sticky_zindex',
			[
				'label'   => __( 'Z-Index', 'mas-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 0,
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);
		$element->add_control(
			'mas-advanced_sticky_offset',
			[
				'label'   => __( 'Offset', 'mas-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 0,
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);
		
		$element->add_control(
			'mas_advanced_sticky_on_scroll_up',
			[
				'label'        => __( 'Show On Scroll Up', 'mas-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' =>'no',
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes',
					'mas_advanced_sticky_position!' => ['column'],
				],
			]
		);
		$element->add_control(
			'mas_advanced_sticky_hide_on_tablet',
			[
				'label'        => __( 'Hide On Tablet', 'mas-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' =>'no',
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);
		$element->add_control(
			'mas_advanced_sticky_hide_on_mobile',
			[
				'label'        => __( 'Hide On Mobile', 'mas-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' =>'no',
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);
		$element->add_control(
			'mas_advanced_sticky_animation',
			[
				'label'        => __( 'Sticky Animation', 'mas-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' =>'no',
				'condition'   => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);
		$element->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'mas-advanced_sticky_box_shadow',
				'label' => __( 'Sticky Box Shadow', 'mas-addons' ),
				'selector' => '{{WRAPPER}}.mas-sticky-open',
				'condition'=>[
					'mas_advanced_sticky_switcher' => 'yes'
				]
			]
		);

		$element->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'mas-advanced_sticky_bg_color',
				'label' => __( 'Background', 'mas-addons' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude'=>['image'],
				'selector' => '{{WRAPPER}}.mas-sticky-open',
				'condition' => [
					'mas_advanced_sticky_switcher' => 'yes'
				],
			]
		);

		$element->end_controls_section();

	}

	
	/**
	 * Render HTML output on the frontend.
	 *
	 * Written in PHP and used to generate the final Output.
	 *
	 * @since 1.6.2
	 * @access public
	 * @param object $element for current element.
	 */
	public function before_render( $element ) {

		$settings = $element->get_settings_for_display();
		$sectionid = $element->get_id();

		if ( 'yes' == $settings['mas_advanced_sticky_switcher'] ) {
            $sticky_settings = [];

			$sticky_settings['position'] = $settings['mas_advanced_sticky_position'];
			$sticky_settings['offset'] = $settings['mas-advanced_sticky_offset'];
			$sticky_settings['z_index'] = $settings['mas_advanced_sticky_zindex'];
			$sticky_settings['sticky_on_scroll_up'] = $settings['mas_advanced_sticky_on_scroll_up'];
			$sticky_settings['hide_on_tablet'] = $settings['mas_advanced_sticky_hide_on_tablet'];
			$sticky_settings['hide_on_mobile'] = $settings['mas_advanced_sticky_hide_on_mobile'];
			$sticky_settings['sticky_animation'] = $settings['mas_advanced_sticky_animation'];

			$element->add_render_attribute( '_wrapper', [
				'data-sticky_settings'=> wp_json_encode( $sticky_settings ),
				'id' => "mas-section-sticky-id-{$sectionid}",
			] );
		}
	}

	 //Check Assets Enqueue
	public function check_assets_enqueue( $element ) {
		if ( self::$assets_load ) {
			return;
		}
		if ( 'yes' === $element->get_settings_for_display( 'mas_advanced_sticky_switcher' ) ) {
			$this->enqueue_styles();
			$this->enqueue_scripts();
			self::$assets_load = true;
			remove_action( 'elementor/frontend/section/before_render', array( $this, 'check_assets_enqueue' ) );
			remove_action( 'elementor/frontend/column/before_render', array( $this, 'check_assets_enqueue' ) );
			remove_action( 'elementor/frontend/container/before_render', array( $this, 'check_assets_enqueue' ) );
		}
	}
}

Mas_Section_Sticky::instance();