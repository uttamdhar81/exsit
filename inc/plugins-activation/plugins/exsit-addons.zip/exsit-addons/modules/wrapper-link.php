<?php
namespace Mas\inc;

use Elementor\Controls_Manager;
use Elementor\Element_Base;

defined('ABSPATH') || die();

class Mas_Wrapper_Link {

	public static function init() {
		// Add controls for Elementor sections, columns, containers
		add_action( 'elementor/element/container/section_layout/after_section_end', [ __CLASS__, 'add_controls_section' ], 1 );
		add_action( 'elementor/element/column/section_advanced/after_section_end', [ __CLASS__, 'add_controls_section' ], 1 );
		add_action( 'elementor/element/section/section_advanced/after_section_end', [ __CLASS__, 'add_controls_section' ], 1 );
		add_action( 'elementor/element/common/_section_style/after_section_end', [ __CLASS__, 'add_controls_section' ], 1 );

		// Add frontend actions
		add_action( 'elementor/frontend/before_render', [ __CLASS__, 'before_section_render' ], 1 );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_scripts' ] );
	}

	// Add custom controls in Elementor
	public static function add_controls_section( Element_Base $element ) {
		$tabs = Controls_Manager::TAB_CONTENT;

		// Define tabs based on the element type
		if ( 'section' === $element->get_name() || 'column' === $element->get_name() || 'container' === $element->get_name() ) {
			$tabs = Controls_Manager::TAB_LAYOUT;
		}

		// Start controls section
		$element->start_controls_section(
			'_section_wrapper_link',
			[
				'label' => __( 'Mas Wrapper Link', 'mas-addons' ).mas_get_section_icon(),
				'tab'   => $tabs,
			]
		);

		// Add URL control
		$element->add_control(
			'mas_element_link',
			[
				'label'       => __( 'Link', 'mas-addons' ),
				'type'        => Controls_Manager::URL,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => 'https://example.com',
			]
		);

		$element->end_controls_section();
	}

	public static function before_section_render( Element_Base $element ) {
		$link_settings = $element->get_settings_for_display( 'mas_element_link' );
		$link_settings['url'] = esc_url( $link_settings['url'] );
		unset( $link_settings['custom_attributes'] );

		if ( $link_settings && ! empty( $link_settings['url'] ) ) {
			$element->add_render_attribute(
				'_wrapper',
				[
					'data-mas-element-link' => json_encode( $link_settings ),
					'style'                   => 'cursor: pointer',
				]
			);
		}
	}

	// Enqueue the JavaScript file
	public static function enqueue_scripts() {
		wp_enqueue_script(
			'mas-wrapper-link',
			MAS_ASSETS_PUBLIC . 'js/wrapper-link.js',
			[ 'jquery' ], 
			false,
			true 
		);
	}
}

Mas_Wrapper_Link::init();
