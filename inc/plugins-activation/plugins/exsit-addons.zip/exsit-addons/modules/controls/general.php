<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// General Controls
$easing_options = [
    'linear' => __( 'Linear', 'lonyo' ),
    'easeInQuad' => __( 'EaseInQuad', 'lonyo' ),
    'easeInCubic' => __( 'EaseInCubic', 'lonyo' ),
    'easeInQuart' => __( 'EaseInQuart', 'lonyo' ),
    'easeInQuint' => __( 'EaseInQuint', 'lonyo' ),
    'easeInSine' => __( 'EaseInSine', 'lonyo' ),
    'easeInExpo' => __( 'EaseInExpo', 'lonyo' ),
    'easeInCirc' => __( 'EaseInCirc', 'lonyo' ),
    'easeInBack' => __( 'EaseInBack', 'lonyo' ),
    'easeOutQuad' => __( 'EaseOutQuad', 'lonyo' ),
    'easeOutCubic' => __( 'EaseOutCubic', 'lonyo' ),
    'easeOutQuart' => __( 'EaseOutQuart', 'lonyo' ),
    'easeOutQuint' => __( 'EaseOutQuint', 'lonyo' ),
    'easeOutSine' => __( 'EaseOutSine', 'lonyo' ),
    'easeOutExpo' => __( 'EaseOutExpo', 'lonyo' ),
    'easeOutCirc' => __( 'EaseOutCirc', 'lonyo' ),
    'easeOutBack' => __( 'EaseOutBack', 'lonyo' ),
    'easeInBounce' => __( 'EaseInBounce', 'lonyo' ),
    'easeInOutQuad' => __( 'EaseInOutQuad', 'lonyo' ),
    'easeInOutCubic' => __( 'EaseInOutCubic', 'lonyo' ),
    'easeInOutQuart' => __( 'EaseInOutQuart', 'lonyo' ),
    'easeInOutQuint' => __( 'EaseInOutQuint', 'lonyo' ),
    'easeInOutSine' => __( 'EaseInOutSine', 'lonyo' ),
    'easeInOutExpo' => __( 'EaseInOutExpo', 'lonyo' ),
    'easeInOutCirc' => __( 'EaseInOutCirc', 'lonyo' ),
    'easeInOutBack' => __( 'EaseInOutBack', 'lonyo' ),
    'easeInOutBounce' => __( 'EaseInOutBounce', 'lonyo' ),
    'easeOutBounce' => __( 'EaseOutBounce', 'lonyo' ),
    'easeOutInQuad' => __( 'EaseOutInQuad', 'lonyo' ),
    'easeOutInCubic' => __( 'EaseOutInCubic', 'lonyo' ),
    'easeOutInQuart' => __( 'EaseOutInQuart', 'lonyo' ),
    'easeOutInQuint' => __( 'EaseOutInQuint', 'lonyo' ),
    'easeOutInSine' => __( 'EaseOutInSine', 'lonyo' ),
    'easeOutInExpo' => __( 'EaseOutInExpo', 'lonyo' ),
    'easeOutInCirc' => __( 'EaseOutInCirc', 'lonyo' ),
    'easeOutInBack' => __( 'EaseOutInBack', 'lonyo' ),
    'easeOutInBounce' => __( 'EaseOutInBounce', 'lonyo' ),
    'custom' => __( 'Custom', 'lonyo' ),
];

$element->add_control(
    'animejs_animation_speed',
    [
        'label' => esc_html__( 'Speed (ms)', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 5000,
        'step' => 50,
        'default' => 500,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_delay',
    [
        'label' => esc_html__( 'Delay (ms)', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 5000,
        'step' => 50,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_easing',
    [
        'label' => __( 'Easing', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'options' => $easing_options,
        'default' => 'easeInCubic',
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_animation_easing_custom',
    [
        'label' => __( 'Custom Easing Function', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'label_block' => true,
        'default' => 'cubicBezier(1, 0, 0, 1)',
		'ai' => [
			'active' => false,
		],
        'condition' => [
            'animejs_animation_type' => 'onview',
            'animejs_animation_easing' => 'custom',
        ],
    ]
);

$element->add_control(
    'animejs_animation_enter',
    [
        'label' => esc_html__( 'Enter Animations', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->start_popover();

$element->add_control(
    'animejs_animation_from_opacity',
    [
        'label' => esc_html__( 'Opacity', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 1,
        'step' => 0.1,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_translateX',
    [
        'label' => __( 'Translate X', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_translateY',
    [
        'label' => __( 'Translate Y', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_scale',
    [
        'label' => __( 'Scale', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_rotate',
    [
        'label' => __( 'Rotate', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_skew',
    [
        'label' => __( 'Skew', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->end_popover();

$element->add_control(
    'animejs_animation_exit',
    [
        'label' => esc_html__( 'Exit Animations', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->start_popover();

$element->add_control(
    'animejs_animation_to_opacity',
    [
        'label' => esc_html__( 'Opacity', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 1,
        'step' => 0.1,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_translateX',
    [
        'label' => __( 'Translate X', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_translateY',
    [
        'label' => __( 'Translate Y', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_scale',
    [
        'label' => __( 'Scale', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_rotate',
    [
        'label' => __( 'Rotate', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_skew',
    [
        'label' => __( 'Skew', 'lonyo' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->end_popover();