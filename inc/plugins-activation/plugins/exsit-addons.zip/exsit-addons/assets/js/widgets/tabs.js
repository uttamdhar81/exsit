(function ($) {
    "use strict";

    var Addons_Tab = function ($scope, $) {
        $scope.find('ul.tabs li').on('click', function () {
            var tab_id = $(this).attr('data-tab');
            $scope.find('ul.tabs li').removeClass('current');
            $scope.find('.mas-addons-tab-content-single').removeClass('current');
            $(this).addClass('current');
            $scope.find("#" + tab_id).addClass('current');
        })
        if ($.fn.magnificPopup) {
            $('.mas-addons-elm-edit').magnificPopup({
                type: 'iframe',
                mainClass: 'mfp-fade mas-addons-elm-edit-popup',
                callbacks: {
                    open: function () {
                    },
                    close: function () {
                        location.reload();

                    }
                }
            });
        }
    };

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/mas-addons-tab.default", Addons_Tab);
    });

})(jQuery);