(function ($) {
    "use strict";
     
    var mas_video_button = function ($scope, $) {

        var modalWrapper = $scope.find('.mas-modal').eq(0),
            modalOverlayWrapper = $scope.find('.mas-modal-overlay'),
            modalItem = $scope.find('.mas-modal-item'),
            modalAction = modalWrapper.find('.mas-modal-image-action'),
            closeButton = modalWrapper.find('.mas-close-btn');
       
            modalAction.on('click', function (e) {
                e.preventDefault();
                var modalOverlay = $(this).closest('.mas-modal').find('.mas-modal-overlay');
                var modal = $(this).data('mas-modal');
                var overlay = $(this).data('mas-overlay');
            
                if (modalOverlay.length) {
                    modalOverlay.addClass('active');
                    console.log("Modal overlay activated.");
                } else {
                    console.error("Modal overlay not found.");
                }
            
                modalItem.css('display', 'block');
                setTimeout(function () {
                    $(modal).addClass('active');
                }, 100);
                if ('yes' === overlay) {
                    console.log("clicked");
                    modalOverlay.addClass('active');
                }
            });
            

        closeButton.on('click', function () {
            var modalOverlay = $(this).parents().eq(3).next();
            var modalItem = $(this).parents().eq(2);
            modalOverlay.removeClass('active');
            modalItem.removeClass('active');

            var modal_iframe = modalWrapper.find('iframe'),
                $modal_video_tag = modalWrapper.find('video');

            if (modal_iframe.length) {
                var modal_src = modal_iframe.attr('src').replace('&autoplay=1', '');
                modal_iframe.attr('src', '');
                modal_iframe.attr('src', modal_src);
            }
            if ($modal_video_tag.length) {
                $modal_video_tag[0].pause();
                $modal_video_tag[0].currentTime = 0;
            }

        });

        modalOverlayWrapper.on('click', function () {
            var overlay_click_close = $(this).data('mas_overlay_click_close');
            if ('yes' === overlay_click_close) {
                $(this).removeClass('active');
                $('.mas-modal-item').removeClass('active');

                var modal_iframe = modalWrapper.find('iframe'),
                    $modal_video_tag = modalWrapper.find('video');

                if (modal_iframe.length) {
                    var modal_src = modal_iframe.attr('src').replace('&autoplay=1', '');
                    modal_iframe.attr('src', '');
                    modal_iframe.attr('src', modal_src);
                }
                if ($modal_video_tag.length) {
                    $modal_video_tag[0].pause();
                    $modal_video_tag[0].currentTime = 0;
                }
            }
        });
    }

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/mas-modal-video.default", mas_video_button);
    });

})(jQuery);