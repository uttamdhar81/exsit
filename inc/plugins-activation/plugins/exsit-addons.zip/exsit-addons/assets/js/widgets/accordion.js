(function ($) {
    "use strict";
     
    var Accordion = function ($scope, $) {
        var accordionTitle = $scope.find('.mas-addons-accordion-title');

        var accmin = $scope.find('.mas-addons-accordion-single-item');

        accmin.each(function () {
            if ($(this).hasClass('yes')) {
                $(this).addClass('wraper-active');
            }
        });

        accordionTitle.each(function () {
            if ($(this).hasClass('active-default')) {
                $(this).addClass('active');
                $(this).next('.mas-addons-accordion-content').slideDown(300);
            }
        });

        // Remove multiple click event for nested accordion
        accordionTitle.unbind('click');

        //$accordionWrapper.children('.mas-addons-accordion-content').first().show();
        accordionTitle.on('click', function (e) {
            e.preventDefault();

            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).next().slideUp(400);
                $(this).parent().removeClass('wraper-active');

            } else {
                $(this).parent().parent().find('.mas-addons-accordion-title').removeClass('active');

                accmin.removeClass('wraper-active');

                $(this).parent('.yes').removeClass('wraper-active');

                $(this).parent().parent().find('.mas-addons-accordion-content').slideUp(300);

                $(this).parent().addClass('wraper-active');

                $(this).toggleClass('active');
                $(this).next().slideToggle(400);

            }
        });
    }

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/mas-addons-accordion.default", Accordion);
    });

})(jQuery);