(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', function () { 
      elementorFrontend.hooks.addAction('frontend/element_ready/mas-offcanvas.default', function ($scope,e) {
        
        $(".mas-berger-icon").on("click", function (event) {
            $(".mas-sidemenu-column, .offcanvas-overlay").addClass("active");
            event.preventDefault(e);
          });
          $(".mas-sidemenu-close, .offcanvas-overlay").on("click", function () {
            $(".mas-sidemenu-column, .offcanvas-overlay").removeClass("active");
          });
      });
    });

})(jQuery);