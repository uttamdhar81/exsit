(function ($) {
    "use strict";
     
    var Pricing_Table = function () {

        $("[data-pricing-trigger]").on("click", function (e) {
            $(e.target).toggleClass("active");
            var target = $(e.target).attr("data-target");
            if ($(target).attr("data-value-active") == "monthly") {
                $(target).attr("data-value-active", "yearly");
            } else {
                $(target).attr("data-value-active", "monthly");
            }
        })

        // Classic tab switcher
        $("[data-pricing-tab-trigger]").on("click", function (e) {
            $('[data-pricing-tab-trigger]').removeClass("active");
            $(this).addClass("active");
            var target = $(e.target).attr("data-target");
            if ($(target).attr("data-value-active") == "monthly") {
                $(target).attr("data-value-active", "yearly");
            } else {
                $(target).attr("data-value-active", "monthly");
            }
        })

    }

    $(window).on("elementor/frontend/init", function () {
        elementorFrontend.hooks.addAction("frontend/element_ready/mas-addons-accordion.default", Pricing_Table);
    });

})(jQuery);