(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', function () { 

        elementorFrontend.hooks.addAction('frontend/element_ready/mas-fun-factor.default', function ($scope) {
            var $fun_factor = $scope.find('.factor-content-number');
            $fun_factor.numerator($fun_factor.data('animation'));
        });

    });

})(jQuery);