(function ($) {
    "use strict";
    $(window).on('elementor/frontend/init', function () { 

        elementorFrontend.hooks.addAction('frontend/element_ready/mas-tabbuilder.default', function ($scope) {
           
            const tabButtons = $scope.find('.mas-tab-buttons .tab-button');
            const tabContents = $scope.find('.tab-content-wrap .tab-content');
        
            
            tabContents.hide().first().slideDown();
            tabButtons.first().addClass('active');
    
            tabButtons.on('click', function() {
                const targetTab = $(this).data('tab'); 
        
               
                tabButtons.removeClass('active');
                $(this).addClass('active');
        
               
                tabContents.hide();
                $('.tab-content[data-tab="' + targetTab + '"]').fadeIn(500);
            });
        });

    });

})(jQuery);