(function($) {
    "use strict";

   
    $(document).ready(function() {
       
        var selectedTab = localStorage.getItem('selectedTab') || $(".admin-nav-tab:first").attr("href");
        $(".admin-nav-tab").removeClass("admin-nav-tab-active");
        $(".exsit-tab-pane").removeClass("active");

        $(".admin-nav-tab[href='" + selectedTab + "']").addClass("admin-nav-tab-active");
        $(selectedTab).addClass("active");

        $(".admin-nav-tab").on("click", function(e) {
            e.preventDefault();

            $(".admin-nav-tab").removeClass("admin-nav-tab-active");
            $(".exsit-tab-pane").removeClass("active");
            
            $(this).addClass("admin-nav-tab-active");

            var targetPane = $(this).attr("href");
            $(targetPane).addClass("active");

            localStorage.setItem('selectedTab', targetPane);
            
            $("html, body").animate({
                scrollTop: $(targetPane).offset().top
            }, 300);
        });

       
        if (!$(".admin-nav-tab-active").length) {
            $(".admin-nav-tab:first").addClass("admin-nav-tab-active");
            $(".exsit-tab-pane:first").addClass("active");
        }
    });

})(jQuery);

