jQuery(document).ready(function ($) {
    $('body').on('click.onWrapperLink', '[data-mas-element-link]', function () {
        var $wrapper = $(this),
            dataString = $wrapper.attr('data-mas-element-link'), // Get data as a string
            data = JSON.parse(dataString), // Parse the string into JSON
            anchor = document.createElement('a'),
            timeout;

        // Ensure the URL exists in the parsed data
        if (!data || !data.url) {
            console.error('No valid URL found for link');
            return;
        }

        // Create and configure the anchor element
        anchor.href = data.url;
        anchor.target = data.is_external ? '_blank' : '_self';
        anchor.rel = data.nofollow ? 'nofollow noreferer' : '';
        anchor.style.display = 'none'; // Hide the anchor element

        // Append the anchor to the body and trigger the click
        document.body.appendChild(anchor);
        anchor.click();

        // Clean up by removing the anchor element
        timeout = setTimeout(function () {
            document.body.removeChild(anchor);
            clearTimeout(timeout);
        }, 100);
    });
});
