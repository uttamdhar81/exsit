;
(function ($) {
  "use strict";

  var ExsitThemeBuilder = {
    instance: [],
    templateId: 0,
    init: function init() {
      this.renderPopup();
      $('#exsit-addons-hf-s-display-type').select2({
        ajax: {
          url: ajaxurl,
          dataType: 'json',
          method: 'post',
          delay: 250,
          data: function data(params) {
            return {
              q: params.term,
              // search term
              page: params.page,
              action: 'exsit_get_posts_by_query',
              'nonce': EXSIT_Theme_Builder.nonce
            };
          },
          processResults: function processResults(data) {

            return {
              results: data
            };
          },
          cache: true
        },
        minimumInputLength: 2
      });

      //open popup onclick
      $('body.post-type-exsit-template #wpcontent').on('click', '.page-title-action, .row-title, .row-actions .edit > a', this.openPopup);
      $(document).on('click', '.exsit-addons-body-overlay,.exsit-template-edit-cross', this.closePopup).on('click', ".exsit-addons-tmp-save", this.savePost).on('click', '.exsit-addons-tmp-elementor', this.redirectEditPage).on('exsit_template_edit_popup_open', this.displayLocation).on('change', '#exsit-template-type, #exsit-addons-hf-display-type', this.displayLocation);
    },
    // Render Popup HTML
    renderPopup: function renderPopup(event) {
      var popupTmp = wp.template('exsit-addons-ctppopup'),
        content = null;
      content = popupTmp({
        templatetype: EXSIT_Theme_Builder.templatetype,
        hflocation: EXSIT_Theme_Builder.hflocation,
        archivelocation: EXSIT_Theme_Builder.archivelocation,
        singlelocation: EXSIT_Theme_Builder.singlelocation,
        editor: EXSIT_Theme_Builder.editor,
        heading: EXSIT_Theme_Builder.labels
      });
      $('body').append(content);
    },
    // Edit PopUp
    openPopup: function openPopup(event) {
      event.preventDefault();
      var rowId = $(this).closest('tr').attr('id'),
        tmpId = null,
        elementorEditlink = null;
      if (rowId) {
        tmpId = rowId.replace('post-', '');
        elementorEditlink = 'post.php?post=' + tmpId + '&action=elementor';
      }
      $('.exsit-addons-tmp-save').attr('data-tmpid', tmpId);
      $('.exsit-addons-tmp-elementor').attr({
        'data-link': elementorEditlink,
        'data-tmpid': tmpId
      });
      if (tmpId) {
        //fetch existing template data
        $.ajax({
          url: EXSIT_Theme_Builder.ajaxurl,
          data: {
            'action': 'exsit_get_template',
            'nonce': EXSIT_Theme_Builder.nonce,
            'tmpId': tmpId
          },
          type: 'POST',
          beforeSend: function beforeSend() { },
          success: function success(response) {
            //type
            document.querySelector("#exsit-template-type option[value='" + response.data.tmpType + "']").selected = "true";
            $('#exsit-template-title').attr('value', response.data.tmpTitle);
            $('.exsit-addons-tmp-elementor').removeClass('disabled').removeAttr('disabled', 'disabled');
          },
          complete: function complete(response) {
            // Fire custom event.
            $(document).trigger('exsit_template_edit_popup_open');

            //display
            var temDisplay = $('.hf-location:visible select, .archive-location:visible select, .single-location:visible select');
            temDisplay.find("option[value='" + response.responseJSON.data.tmpLocation + "']")[0].selected = "true";

            //display specific locations
            if (response.responseJSON.data.tmpSpLocation) {
              $.each(response.responseJSON.data.tmpSpLocation, function (i, item) {
                // Create a DOM Option and pre-select by default
                var data = {
                  id: i,
                  text: item
                };
                var newOption = new Option(data.text, data.id, true, true);
                // Append it to the select
                $('#exsit-addons-hf-s-display-type').append(newOption).trigger('change');
              });
            }
            $('.exsit-template-edit-popup-area').addClass('open-popup');
          },
          error: function error(errorThrown) {
            console.log(errorThrown);
          }
        });
      } else {
        // Fire custom event.
        $(document).trigger('exsit_template_edit_popup_open');
        $('.exsit-addons-tmp-elementor').addClass('button disabled').attr('disabled', 'disabled');
        $('.exsit-template-edit-popup-area').addClass('open-popup');
      }
    },
    // Close Popup
    closePopup: function closePopup(event) {
      $('.exsit-template-edit-popup-area').removeClass('open-popup');
    },
    // Save Post
    savePost: function savePost(event) {
      var _JSON$stringify;
      var $this = $(this),
        tmpId = event.target.dataset.tmpid ? event.target.dataset.tmpid : '',
        title = $('#exsit-template-title').val(),
        tmpType = $('#exsit-template-type').val(),
        temDisplay = $('.hf-location:visible select, .archive-location:visible select, .single-location:visible select').val(),
        specificsDisplay = $('.hf-s-location:visible select').val();
      $.ajax({
        url: EXSIT_Theme_Builder.ajaxurl,
        data: {
          'action': 'exsit_save_template',
          'nonce': EXSIT_Theme_Builder.nonce,
          'tmpId': tmpId,
          'title': title,
          'tmpType': tmpType,
          'tmpDisplay': temDisplay,
          'specificsDisplay': (_JSON$stringify = JSON.stringify(specificsDisplay)) !== null && _JSON$stringify !== void 0 ? _JSON$stringify : null
        },
        type: 'POST',
        beforeSend: function beforeSend() {
          $this.text(EXSIT_Theme_Builder.labels.buttons.save.saving);
          $this.addClass('updating-message');
        },
        success: function success(data) {
          if (tmpId == '') {
            if (data.data.id) {
              var elementorEditlink = 'post.php?post=' + data.data.id + '&action=elementor';
            }
            $('.exsit-addons-tmp-save').attr('data-tmpid', data.data.id);
            $('.exsit-addons-tmp-elementor').attr({
              'data-link': elementorEditlink,
              'data-tmpid': data.data.id
            });
            $('.exsit-addons-tmp-elementor').removeClass('disabled').removeAttr('disabled', 'disabled');
          } else { }
        },
        complete: function complete(data) {
          $('body.post-type-woolentor-template').removeClass('loading');
          $this.removeClass('updating-message');
          $this.text(EXSIT_Theme_Builder.labels.buttons.save.saved);
        },
        error: function error(errorThrown) {
          console.log(errorThrown);
        }
      });
    },
    // Redirect Edit Page
    redirectEditPage: function redirectEditPage(event) {
      event.preventDefault();
      var $this = $(this),
        link = $this.data('link') ? $this.data('link') : '';
      window.location.replace(EXSIT_Theme_Builder.adminURL + link);
    },
    displayLocation: function displayLocation(event) {
      var type = $('#exsit-template-type').val();
      $('.hf-s-location').addClass('hidden');
      if ('archive' === type) {
        $('.archive-location').removeClass('hidden');
        $('.hf-location, .single-location').addClass('hidden');
      } else if ('single' === type) {
        $('.single-location').removeClass('hidden');
        $('.hf-location, .archive-location').addClass('hidden');
      } else {
        $('.hf-location').removeClass('hidden');
        $('.single-location, .archive-location').addClass('hidden');
        setTimeout(function () {
          //specifics location for page post taxonomy etc
          if ('specifics' === $('#exsit-addons-hf-display-type').val()) {
            $('.hf-s-location').removeClass('hidden');
          }
        }, 100);
      }
    }
  };
  ExsitThemeBuilder.init();
})(jQuery);