<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Exsit Mega Menu Builder
 */
class Exsit_Mega_Menu_Builder {

    public function __construct() {

        // Register CPT
        add_action('init', [$this, 'register_post_type']);

        // Admin Menu
        add_action('admin_menu', [$this, 'register_admin_menu']);

        // Load Elementor Canvas
        add_filter('single_template', [$this, 'load_canvas_template']);
    }

    /**
     * Register Mega Menu CPT
     */
    public function register_post_type() {

        $labels = [
            'name'               => __('Mega Menu', 'exsit-addons'),
            'singular_name'      => __('Mega Menu', 'exsit-addons'),
            'menu_name'          => __('Mega Menu', 'exsit-addons'),
            'add_new'            => __('Add New', 'exsit-addons'),
            'add_new_item'       => __('Add New Mega Menu', 'exsit-addons'),
            'edit_item'          => __('Edit Mega Menu', 'exsit-addons'),
            'new_item'           => __('New Mega Menu', 'exsit-addons'),
            'view_item'          => __('View Mega Menu', 'exsit-addons'),
            'all_items'          => __('All Mega Menu', 'exsit-addons'),
            'search_items'       => __('Search Mega Menu', 'exsit-addons'),
            'not_found'          => __('No Mega Menu found.', 'exsit-addons'),
            'not_found_in_trash' => __('No Mega Menu found in Trash.', 'exsit-addons'),
        ];

        $args = [
            'labels'              => $labels,
            'public'              => true,
            'rewrite'             => false,
            'show_ui'             => true,
            'show_in_menu'        => false,
            'show_in_nav_menus'   => false,
            'exclude_from_search' => true,
            'capability_type'     => 'post',
            'hierarchical'        => false,
            'supports'            => ['title', 'editor', 'elementor'],
        ];

        register_post_type('exsit-mega-menu', $args);
    }

    /**
     * Add Admin Menu
     */
    public function register_admin_menu() {
        

        add_submenu_page(
            'exsit-page',
            __('Mega Menu', 'exsit-addons'),
            __('Mega Menu', 'exsit-addons'),
            'manage_options',
            'edit.php?post_type=exsit-mega-menu'
        );
    }

    /**
     * Load Elementor Canvas Template
     */
    public function load_canvas_template($single_template) {
        global $post;

        if ($post && $post->post_type === 'exsit-mega-menu') {

            $canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

            if (file_exists($canvas)) {
                return $canvas;
            } else {
                return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
            }
        }

        return $single_template;
    }
}

// Init
new Exsit_Mega_Menu_Builder();