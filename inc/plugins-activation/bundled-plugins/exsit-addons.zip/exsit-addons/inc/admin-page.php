<?php
namespace ExsitAddons\inc;

if ( ! defined( 'ABSPATH' ) ) exit;

class Admin_Page {

    private static $_instance = null;
    private $settings_api;

    public function __construct() { 

        add_action( 'admin_menu', array($this, 'admin_menu'), 99 );
        add_action( 'admin_enqueue_scripts', [$this, 'exsit_admin_enqueue_script'] );
        $this->remove_all_notices();
    }

    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function admin_menu() {
        add_menu_page( 
            esc_html__( 'Exsit Addons', 'exsit-addons' ), 
            esc_html__( 'Exsit Addons', 'exsit-addons' ),
            'manage_options',
            'exsit-page', 
            array($this, 'exsit_about_page'), 
            'dashicons-admin-generic',
            40
        );

    }

    public function exsit_about_page() {
        echo '<div class="exsit-page-wrap">';
        echo '<h4>' . esc_html__( 'Welcome To Exsit Addons', 'exsit-addons' ) . '</h4>';
        echo '</div>';
    }

    public function exsit_settings_page() {
        if ( isset( $_GET['settings-updated'] ) ) {
            printf( '<div class="updated"><p>%s</p></div>', esc_html__( 'Settings updated successfully', 'exsit-addons' ) );
        }

        $sections = $this->exsit_settings_sections();
        
        echo '<div class="exsit-settings-tabs">';
        echo '<div class="admin-nav-tab-wrapper">';
        
        foreach ( $sections as $index => $section ) {
            $active_class = $index === 0 ? 'admin-nav-tab-active' : '';
            echo '<a href="#' . esc_attr( $section['id'] ) . '" class="admin-nav-tab ' . esc_attr( $active_class ) . '">';
            echo '<span class="' . esc_attr( $section['icon'] ) . '"></span> ';
            echo esc_html( $section['title'] );
            echo '</a>';
        }
        
        echo '</div>';
        echo '<div class="exsit-tab-content">';
        
        foreach ( $sections as $index => $section ) {
            $active_class = $index === 0 ? 'active' : '';
            echo '<div id="' . esc_attr( $section['id'] ) . '" class="exsit-tab-pane ' . esc_attr( $active_class ) . '">';
            $this->settings_api->exsit_show_forms( $section['id'] );
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
    }

    public function exsit_settings_sections() {
        return array(
            array(
                'id'    => 'exsit_widgets',
                'title' => esc_html__( 'Elements', 'exsit-addons' ),
                'icon'  => 'dashicons dashicons-admin-tools',
            ),
            array(
                'id'    => 'exsit_features',
                'title' => esc_html__( 'Features', 'exsit-addons' ),
                'icon'  => 'dashicons dashicons-admin-site-alt3',
            ),
            array(
                'id'    => 'exsit_dynamic',
                'title' => esc_html__( 'Dynamic Elements', 'exsit-addons' ),
                'icon'  => 'dashicons dashicons-admin-generic',
            )
        );
    }

    public function exsit_admin_enqueue_script() {
        if (is_admin()) { 
            wp_enqueue_style( 'exsit-admin-page', EXSIT_ASSETS_PUBLIC . 'css/admin-page.css', [], '1.0.0', 'all' );
            wp_enqueue_script( 'exsit-admin-page', EXSIT_ASSETS_PUBLIC . 'js/admin-page.js', ['jquery'], '1.0.0', true );
            
        }
        
    }
    /**
	 * [remove_all_notices] remove addmin notices
	 * @return [void]
	 */
	public function remove_all_notices() {
		add_action( 'in_admin_header', function () {
			if ( isset( $_GET['page'] ) && $_GET['page'] == 'exsit-settings' ) {
				remove_all_actions( 'admin_notices' );
				remove_all_actions( 'all_admin_notices' );
			}
		}, 1000 );
	}
}

Admin_Page::instance();