<?php

function exsit_nav_fields($item_id, $item)
{
    wp_nonce_field('exsit_menu_meta_nonce', 'exsit_menu_meta_nonce_name');
    $exsit_menu_meta = get_post_meta($item_id, 'exsit_select_megamenu', true);
    
    $megamenu = get_posts([
        'post_type'      => 'exsit-mega-menu',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
    ]);

    if (!empty($megamenu)) {
        ?>
        <div class="field-exsit_menu_meta description-wide" style="margin: 5px 0;">
            <span class="description"><?php _e("Select Megamenu", 'exsit'); ?></span>
            <br />
            <input type="hidden" class="nav-menu-id" value="<?php echo esc_attr($item_id); ?>" />
            <div class="logged-input-holder">
                <select name="<?php echo esc_attr('exsit_select_megamenu[' . $item_id . ']') ?>" id="<?php echo esc_attr('exsit_select_megamenu[' . $item_id . ']') ?>">
                    <?php
                    echo '<option value="">' . esc_html('Select megamenu') . '</option>';
                    foreach ($megamenu as $mm) {
                        $terms = wp_get_post_terms($mm->ID, 'tb_type', ['fields' => 'names']);
                        
                        // Check for WP_Error
                        if (is_wp_error($terms)) {
                            $is_MM = '';  // Handle error
                        } else {
                            $is_MM = isset($terms[0]) ? $terms[0] : '';
                        }
                        $selected = $exsit_menu_meta == $mm->ID ? 'selected' : '';
                        echo '<option ' . esc_attr($selected) . ' value="' . esc_attr($mm->ID) . '">' . esc_html($mm->post_title) . '</option>';
                    }
                    ?>
                </select>
            </div>
        </div>
        <?php
    }
}
add_action('wp_nav_menu_item_custom_fields', 'exsit_nav_fields', 10, 2);

function exsit_nav_update($menu_id, $menu_item_db_id)
{
    if (!isset($_POST['exsit_menu_meta_nonce_name']) || !wp_verify_nonce($_POST['exsit_menu_meta_nonce_name'], 'exsit_menu_meta_nonce')) {
        return $menu_id;
    }
    
    if (isset($_POST['exsit_select_megamenu'][$menu_item_db_id])) {
        $sanitized_data = sanitize_text_field($_POST['exsit_select_megamenu'][$menu_item_db_id]);
        update_post_meta($menu_item_db_id, 'exsit_select_megamenu', $sanitized_data);
    } else {
        delete_post_meta($menu_item_db_id, 'exsit_select_megamenu');
    }
}
add_action('wp_update_nav_menu_item', 'exsit_nav_update', 10, 2);


function exsit_addons_megamenu_builder_integrations($item_output, $item, $depth, $args)
{
    $mega_id = get_post_meta($item->ID, 'exsit_select_megamenu', true);

    if (!empty($mega_id) && !isset($_GET['elementor-preview'])) {

        $content = '';

        if (class_exists('\Elementor\Plugin')) {
            $content = \Elementor\Plugin::instance()
                ->frontend
                ->get_builder_content_for_display($mega_id);
        }

        $item_output .= '<ul class="mega-menu exsit-megamenu"><li>' . $content . '</li></ul>';
    }

    return $item_output;
}
add_filter('walker_nav_menu_start_el', 'exsit_addons_megamenu_builder_integrations', 10, 4);

function exsit_implement_menu_meta($classes, $item)
{
    $class = get_post_meta($item->ID, 'exsit_select_megamenu', true) ? 'menu-item-has-children mega-menu-wrap' : '';
    $classes[] = $class;
    return $classes;
}
add_filter('nav_menu_css_class', 'exsit_implement_menu_meta', 10, 2);
