<?php
/*
 * Plugin Name:       Exsit Addons
 * Plugin URI:        https://uicobe.com/
 * Description:       This is a helper plugin of Exsit theme. This plugin will make your design work easier.
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Your Name
 * Author URI:        https://uicobe.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       exsit-addons
 * Domain Path:       exsit-addons
 */

//  Exit if accessed directly.
if( ! defined( 'ABSPATH' ) ) {
    exit();
}
define( 'EXSIT_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'EXSIT_PLUGIN_INC_PATH', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'EXSIT_PLUGIN_INCLUDE_PATH', plugin_dir_path( __FILE__ ) . 'include/' );
define( 'EXSIT_PLUGIN_WIDGET_PATH', plugin_dir_path( __FILE__ ) . 'widgets/' );
define( 'EXSIT_PLUGDIRURI', plugin_dir_url( __FILE__ ) );
define('EXSIT_ASSETS_PUBLIC', plugins_url('assets/', __FILE__));

// include base file   
require EXSIT_PLUGIN_PATH . 'base.php';
\ExsitAddons\Base::instance();

/**
 * Add custom action links on the plugins page.
 */
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'exsit_plugin_action_links' );

function exsit_plugin_action_links( $links ) {

    $settings_link = '<a href="admin.php?page=exsit-settings">Settings</a>';
    
    array_unshift( $links, $settings_link );
    
    return $links;
}
