<?php
namespace ExsitAddons;

if ( ! defined( 'ABSPATH' ) ) exit;

final class Base {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Elementor_Test_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Elementor_Test_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
		register_activation_hook(__FILE__, [ $this, 'update_options_on_activation' ]);
	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// translated this plugin
		load_plugin_textdomain( 'prefix', false, basename( dirname( __FILE__ ) ) . '/languages' );

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Register widget scripts
		// add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ]);
		add_action('elementor/editor/after_enqueue_scripts',[$this,'editor_scripts'] );
		
		

		// inlude all file
		$this->exsit_include_file();
	}

	/**
	 * include all file here
	 *
	 * @return void
	 */
	public function exsit_include_file() {

		if ( is_admin() ) {
			require EXSIT_PLUGIN_INC_PATH . 'admin-page.php';
		}
		require EXSIT_PLUGIN_INC_PATH . 'mega-menu.php';
		require EXSIT_PLUGIN_INC_PATH . 'theme-builder.php';	
		require EXSIT_PLUGIN_PATH . 'builder/builder.php';	
	}

	/**
	 * widget_scripts
	 */
	public function widget_scripts() {

		// include all css
		wp_enqueue_style( 'slick-style', EXSIT_ASSETS_PUBLIC.'css/slick.css', [],'1.0.0', 'all' );
		wp_enqueue_style( 'widget-style', EXSIT_ASSETS_PUBLIC.'css/widget-style.css', [],'1.0.0', 'all' );
		

		
		wp_enqueue_script(
            'slick-script',
            EXSIT_ASSETS_PUBLIC . 'js/slick.min.js',
            array('jquery'),
            '1.0.0',
            true
		);
	}

	public function editor_scripts() {

		// style css
		
		wp_enqueue_style( 'exsit-editor', EXSIT_ASSETS_PUBLIC . 'css/editor.css', ['elementor-editor'], '1.0.0', 'all' );
		wp_localize_script('editor-scripts', 'ajax_object', [
			'ajax_url' => admin_url('admin-ajax.php'), // Correctly localize the ajax_url
		]);
	}
	
	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'exsit-addons' ),
			'<strong>' . esc_html__( 'Exsit Addons', 'exsit-addons' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'exsit-addons' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'exsit-addons' ),
			'<strong>' . esc_html__( 'Exsit Addons', 'exsit-addons' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'exsit-addons' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'exsit-addons' ),
			'<strong>' . esc_html__( 'Exsit Addons', 'exsit-addons' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'exsit-addons' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

}